export default {
    install(Vue, options) {
        Vue.prototype.formatDuring = function (a) {
            return a*a
            // var days = parseInt(mss / (1000 * 60 * 60 * 24));
            // var hours = parseInt((mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            // var minutes = parseInt((mss % (1000 * 60 * 60)) / (1000 * 60));
            // var seconds = (mss % (1000 * 60)) / 1000;
            // return days + " 天 " + hours + " 小时 " + minutes + " 分 " + Math.round(seconds) + " 秒 ";
        },
        Vue.prototype.tete = function (i){
            return i+i;
        }
    }
}


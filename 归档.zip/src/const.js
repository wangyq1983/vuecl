const TITLE = '墨子项目';
const VER = 1.01;
const COPYRIGHT = '海马云'
module.exports = {
    TITLE,
    VER,
    COPYRIGHT
};

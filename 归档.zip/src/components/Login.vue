<template>
  <div>
    <div>账户 <input type="text" id="username" ref="username" v-model.trim="username"></div>
    <div>密码 <input type="password" id="password" ref="password" v-model.trim="password"></div>
    <div>
      <div v-if="isempty">{{loginEmpty}}</div>
      <div v-if="iserror">{{loginError}}</div>
    </div>
    <div>
      <button id="login" @click="eventEnter">登录</button>
    </div>
  </div>
</template>

<script>
  var userName = 'admin';
  var passWord = '123456';
  export default {
    data(){
      return {
        username:'',
        password:'',
        isempty:false,
        iserror:false,
        loginError: '账户名称或密码错误,请重新输入!',
        loginEmpty: '账户或密码不可为空!',
      }
    },
    methods: {
      eventEnter: function () {
        this.isempty = false;
        this.iserror = false;
        //let username = this.$refs.username.value;
        //let password = this.$refs.password.value;
        if (this.username == userName && this.password == passWord) {
          console.log('success');
          //this.$router.go('/');
          localStorage.setItem('isLogin',true);
          this.$router.push({path:'/'});
        }else{
          if (this.username == '' || this.password == '') {
            this.isempty = true;
          }else{
            this.iserror = true
          }
        }
        console.log('enter');
      }
    }
  }
</script>

<style>

</style>

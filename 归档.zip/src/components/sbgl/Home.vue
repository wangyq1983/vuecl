<template>
    <div>
        home
      <p>
       store.state.count is {{$store.state.count}}
      </p>

    </div>
</template>
<script>

import store from '@/vuex/store';

export default {
    data(){
      return {

      }
    },
    store
}
</script>
<style>

</style>

<template>
    <div class="subCon">
        <SubTitle titles="点位列表" />
        <div class="filterBar">
            省份 <el-input v-model="shengfen" placeholder="省份"></el-input>
            区县 <el-input v-model="quxian" placeholder="区县"></el-input>
            <span style="padding-left:10px;">状态</span>
            <el-select v-model="selectState" placeholder="请选择">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
            <span style="padding-left:10px;">时间</span>
            <el-date-picker
                v-model="value13"
                type="daterange"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                value-format="timestamp"
                :default-time="['00:00:00', '23:59:59']">
            </el-date-picker>
            <el-button type="primary" style="margin-right:30px;">筛选</el-button>

            <el-select v-model="orderBy" placeholder="请选择" class="orderBy">
                <el-option
                v-for="oitem in orders"
                :key="oitem.value"
                :label="oitem.label"
                :value="oitem.value">
                </el-option>
            </el-select>
            <el-button type="primary">排序</el-button>
        </div>
        <div style="width:100%;">
            <table class="tableList">
                <tr style="background:#ddd">
                    <th>点位名称</th>
                    <th>省份</th>
                    <th>区县</th>
                    <th>IP地址</th>
                    <th>点位状态</th>
                    <th>车流量</th>
                    <th>疑似黑烟车</th>
                    <th>黑烟车比例</th>
                </tr>
                <!--<tr v-for = "(dsList,index) in dsLists">-->
                    <!--<td>{{index}}+{{dsList.gid}}</td>-->
                    <!--<td>{{dsList.name}}</td>-->
                    <!--<td>1</td>-->
                    <!--<td>1</td>-->
                    <!--<td>1</td>-->
                    <!--<td>1</td>-->
                    <!--<td>1</td>-->
                    <!--<td><el-button type="primary" round>查看</el-button></td>-->
                <!--</tr>-->
                <tr v-for="(yjjList,index) in yjjLists">
                  <td>{{index}}+{{yjjList.entity_id}}</td>
                  <td>{{yjjList.name}}</td>
                  <td>{{yjjList.orgname}}</td>
                  <td>{{yjjList.address}}</td>
                  <td>{{yjjList.platform_count}}</td>
                  <td>{{yjjList.question_desc[0]}}</td>
                  <td>{{yjjList.orgcode}}</td>
                  <td>{{yjjList.bad_comment_rate}}</td>
                </tr>
            </table>
        </div>
      <h5>el-pagination</h5>
        <el-pagination
            background
            layout=" prev, pager, next, jumper"
            @current-change="handleCurrentChange"
            :page-size = "20"
            :total="total" style="margin-top:30px;">
        </el-pagination>
    </div>
</template>
<script>
import SubTitle from "../SubTitle";
//import $ from "../../promise/myaxios";
import axios from "../../promise/myaxios";
// import *as Toolkit from '../../toolkit.js'
// import *as Mconst from '../../const.js'

var api1 =
  "http://api-dev.jiyoushe.cn/v2/rank/ranking_country_list?from=1&to=30&type=1";
var api2 =
  "http://192.168.100.216:8013/v1/warning/list?from=1&to=20&entity_name=&orgcode=0&qid=&platform=&city=lanzhou&_=1526883702392";
var api3 = "/api/api.php?url_param=warning/list"
//var api3 = "http://192.168.100.216:8004/api.php?url_param=analyze/alldetail&orgcode=1"
let needLoadingRequestCount = 0

export default {
  data() {
    return {
        total: 150,     // 记录总条数
        display: 10,   // 每页显示条数
        current: 1,   // 当前的页数
        shengfen:'',
        quxian:'',
        value13: [],
        dsLists: [],
        yjjLists:[],
        orders: [
            {
                value: 1,
                label:'按疑似黑烟车数量'
            }
        ],
        options: [{
          value: 1,
          label: '正常'
        }, {
          value: 2,
          label: '异常'
        }, {
          value: 3,
          label: '停用'
        }],
        orderBy:'按疑似黑烟车数量',
        selectState: ''
    };
  },
  methods: {
    handleCurrentChange:function (curpage) {
      console.log(curpage);
      axios.get(api3,{
        headers:{
          'YJJSID':'lcvllot2gc5bimeomriuui7uk7',
          'YJJUSERNAME':'yunnan',
          'YJJTOKEN':'_G9MvFdBLEBYgPRFlvF4vVif8Ov087RI'
        },
        params: {
          from: (curpage-1)*20+1,
          to: (curpage-1)*20+20,
          entity_name:'',
          entity_id:'',
          orgcode:'',
          qid:'',
          platform:'',
          province:53
        },
      }).then(response =>{
        console.log(response);
        this.yjjLists = response.data.data.entitys;
        this.total = Number(response.data.data.count);
      }).catch(function(error) {
        console.log(error);
      });
    }
   },
  components: {
    SubTitle
  },
  created: function() {
//    axios.get(api1)
//      // .then(function (response) {
//      //     console.log(response);
//      //     console.log(response.data.data);
//      //     this.dsLists = response.data.data;
//      //     console.log(this.dsLists)
//      // }.bind(this))
//      .then(response => {
//        console.log(response);
//        this.dsLists = response.data.data;
//      })
//      .catch(function(error) {
//        console.log(error);
//      });

    axios.get(api3,{
      headers:{
        'YJJSID':'lcvllot2gc5bimeomriuui7uk7',
        'YJJUSERNAME':'yunnan',
        'YJJTOKEN':'_G9MvFdBLEBYgPRFlvF4vVif8Ov087RI'
      },
      params: {
        from: (this.current-1)*20+1,
        to: (this.current-1)*20+20,
        entity_name:'',
        entity_id:'',
        orgcode:'',
        qid:'',
        platform:'',
        province:53
      },
    }).then(response =>{
      console.log(response);
      this.yjjLists = response.data.data.entitys;
      this.total = Number(response.data.data.count);
    }).catch(function(error) {
      console.log(error);
    });
    //   console.log(Mconst.TITLE);
    //   console.log(Toolkit.testMz())
    // console.log(this.formatDuring(9));
    // console.log(this.tete(98));
  },
  updated:function(){
      console.log(this.value13[0])
  }
};
</script>
<style>
@import "../../assets/css/public";
.el-input{
    width:90px;
}
.orderBy .el-input{
    width:160px;
}
.el-date-editor--daterange.el-input, .el-date-editor--daterange.el-input__inner, .el-date-editor--timerange.el-input, .el-date-editor--timerange.el-input__inner{
    width:240px;
}
</style>

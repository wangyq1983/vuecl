<template>
    <div>
        <div class="t_menu">
            <ul>
                <li @click="tmenu" data-id="1">t1</li>
                <li @click="tmenu" data-id="2">t2</li>
                <li @click="tmenu" data-id="3">t3</li>
            </ul>
        </div>
        <div class="t_con">
            <div v-if="menuid == 1">
                {{menuid}}
            </div>
            <div v-if="menuid == 2">
                {{menuid}}
            </div>
            <div v-if="menuid == 3">
                {{menuid}}
            </div>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      menuid: "1"
    };
  },
  methods: {
    tmenu: function(e) {
      console.log(e);
      console.log(e.target.dataset.id);
      this.menuid = e.target.dataset.id;
    }
  }
};
</script>
<style>
</style>
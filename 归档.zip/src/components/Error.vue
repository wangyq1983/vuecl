<template>
  <div class="errtest">
    {{msg}}
  </div>
</template>

<script>
  export default {
    data(){
      return {
        msg:'404'
      }
    }
  }
</script>

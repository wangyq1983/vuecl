<template>
  <div>
    <h2>{{msg}}</h2>
    <hr/>
    <h3>{{$store.state.count}}</h3>
    <div>
      <button @click="$store.commit('add')">+</button>
      <button @click="$store.commit('reduce')">-</button>
    </div>
    <router-link to="/">home</router-link>
  </div>
</template>

<script>

import store from '@/vuex/store';
  export default{
    data(){
      return{
        msg:'hello vuex',
      }
    },
    store
  }
</script>

<style>
</style>

<template>
  <div>
    <Sbgl></Sbgl>
  </div>
</template>

<script>
  
  import Sbgl from './Sbgl';
  export default {
    data(){
      return{
        
      }
    },
    components:{
      "Sbgl":Sbgl
    }
  }
</script>
<style>
  .mzCon{
    margin-left:200px;
  }
</style>



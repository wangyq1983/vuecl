export const testMz = function(){
    return 'testmz'
}
